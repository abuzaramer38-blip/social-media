import { useState, useEffect } from 'react'
import Home from './pages/Home.jsx'
import Setup from './pages/Setup.jsx'
import Accounts from './pages/Accounts.jsx'
import Posts from './pages/Posts.jsx'
import History from './pages/History.jsx'
import Sidebar from './components/Sidebar.jsx'

const STORAGE_KEY = 'social_agent_data'

const defaultData = {
  shopName: '',
  bio: '',
  address: '',
  phone: '',
  email: '',
  emailPassword: '',
  accsPassword: '',
  profileImage: null,
  platforms: {
    tiktok: { username: '', password: '', status: 'pending', createdAt: null },
    instagram: { username: '', password: '', status: 'pending', createdAt: null },
    facebook: { username: '', password: '', status: 'pending', createdAt: null },
    youtube: { username: '', password: '', status: 'pending', createdAt: null },
  },
  posts: [],
  history: []
}

export default function App() {
  const [page, setPage] = useState('home')
  const [data, setData] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      return saved ? { ...defaultData, ...JSON.parse(saved) } : defaultData
    } catch { return defaultData }
  })

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  }, [data])

  const updateData = (updates) => setData(prev => ({ ...prev, ...updates }))

  const addHistory = (entry) => {
    setData(prev => ({
      ...prev,
      history: [{ ...entry, id: Date.now(), timestamp: new Date().toISOString() }, ...prev.history]
    }))
  }

  const pages = { home: Home, setup: Setup, accounts: Accounts, posts: Posts, history: History }
  const PageComponent = pages[page] || Home

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar currentPage={page} setPage={setPage} data={data} />
      <main style={{ flex: 1, marginLeft: 260, padding: '32px 40px', minHeight: '100vh' }}>
        <PageComponent data={data} updateData={updateData} addHistory={addHistory} setPage={setPage} />
      </main>
    </div>
  )
}
