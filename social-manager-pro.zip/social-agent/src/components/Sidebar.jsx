const icons = {
  home: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
    </svg>
  ),
  setup: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 1.45 14.4M4.93 4.93a10 10 0 0 0-1.45 14.4M12 2v2M12 20v2M2 12h2M20 12h2"/>
    </svg>
  ),
  accounts: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  posts: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>
    </svg>
  ),
  history: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
    </svg>
  ),
}

const platformStatus = (data) => {
  const plats = data.platforms || {}
  const done = Object.values(plats).filter(p => p.status === 'done').length
  return `${done}/4 active`
}

export default function Sidebar({ currentPage, setPage, data }) {
  const navItems = [
    { id: 'home', label: 'Dashboard' },
    { id: 'setup', label: 'Shop Setup' },
    { id: 'accounts', label: 'Accounts' },
    { id: 'posts', label: 'Posts' },
    { id: 'history', label: 'History' },
  ]

  const platformColors = {
    tiktok: '#ff2d55', instagram: '#e1306c', facebook: '#1877f2', youtube: '#ff0000'
  }

  return (
    <div style={{
      width: 260,
      position: 'fixed',
      top: 0,
      left: 0,
      height: '100vh',
      background: '#0e0e16',
      borderRight: '1px solid rgba(255,255,255,0.07)',
      display: 'flex',
      flexDirection: 'column',
      padding: '28px 0',
      zIndex: 100
    }}>
      <div style={{ padding: '0 24px', marginBottom: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'linear-gradient(135deg, #7c5cfc, #a855f7)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
              <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
            </svg>
          </div>
          <div>
            <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: 15, color: '#f0f0f8' }}>Social Manager</div>
            <div style={{ fontSize: 11, color: '#5a5a7a' }}>Pro Agent</div>
          </div>
        </div>
      </div>

      {data.shopName && (
        <div style={{
          margin: '0 16px 24px',
          padding: '12px 14px',
          background: 'rgba(124,92,252,0.1)',
          borderRadius: 12,
          border: '1px solid rgba(124,92,252,0.2)'
        }}>
          {data.profileImage ? (
            <img src={data.profileImage} alt="" style={{ width: 36, height: 36, borderRadius: '50%', objectFit: 'cover', marginBottom: 8, display: 'block' }} />
          ) : (
            <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: 'linear-gradient(135deg, #7c5cfc, #a855f7)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'white', fontWeight: 700, fontSize: 14, marginBottom: 8
            }}>{data.shopName[0]?.toUpperCase()}</div>
          )}
          <div style={{ fontSize: 13, fontWeight: 600, color: '#f0f0f8', fontFamily: 'Syne' }}>{data.shopName}</div>
          <div style={{ fontSize: 11, color: '#9898b8', marginTop: 2 }}>{platformStatus(data)}</div>
        </div>
      )}

      <nav style={{ flex: 1, padding: '0 12px' }}>
        {navItems.map(item => (
          <button key={item.id} onClick={() => setPage(item.id)} style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '11px 14px',
            borderRadius: 10,
            border: 'none',
            background: currentPage === item.id ? 'rgba(124,92,252,0.15)' : 'transparent',
            color: currentPage === item.id ? '#a78bfa' : '#6868a0',
            fontSize: 14,
            fontWeight: currentPage === item.id ? 500 : 400,
            marginBottom: 2,
            transition: 'all 0.15s',
            textAlign: 'left',
            cursor: 'pointer'
          }}>
            <span style={{ color: currentPage === item.id ? '#a78bfa' : '#4a4a72' }}>{icons[item.id]}</span>
            {item.label}
            {currentPage === item.id && (
              <div style={{ marginLeft: 'auto', width: 4, height: 4, borderRadius: '50%', background: '#a78bfa' }} />
            )}
          </button>
        ))}
      </nav>

      <div style={{ padding: '0 16px 0' }}>
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: 20 }}>
          <div style={{ fontSize: 10, color: '#3a3a5a', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 12, paddingLeft: 2 }}>Platforms</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {Object.entries(data.platforms || {}).map(([name, info]) => (
              <div key={name} style={{
                padding: '8px 10px',
                borderRadius: 8,
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.05)',
                display: 'flex', flexDirection: 'column', gap: 4
              }}>
                <div style={{ fontSize: 10, color: platformColors[name] || '#9898b8', textTransform: 'capitalize', fontWeight: 600 }}>{name}</div>
                <div style={{
                  width: 6, height: 6, borderRadius: '50%',
                  background: info.status === 'done' ? '#22c55e' : info.status === 'progress' ? '#f59e0b' : '#3a3a5a'
                }} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
