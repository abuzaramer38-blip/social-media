import { useState } from 'react'

const platformMeta = {
  tiktok: {
    label: 'TikTok',
    color: '#ff2d55',
    bg: 'rgba(255,45,85,0.1)',
    border: 'rgba(255,45,85,0.2)',
    steps: [
      'TikTok app download karo ya tiktok.com kholo',
      'Sign Up pe click karo',
      'Email se register karo → Email: ' + '(Setup mein di hui email use karo)',
      'Password: Accounts wala password dalo',
      'Username mein shop ka naam dalo (agar na mile tu number add karo)',
      'Bio paste karo',
      'Profile image upload karo',
      'Phone number aur address add karo',
      'Wapas ao aur username save karo'
    ]
  },
  instagram: {
    label: 'Instagram',
    color: '#e1306c',
    bg: 'rgba(225,48,108,0.1)',
    border: 'rgba(225,48,108,0.2)',
    steps: [
      'Instagram.com ya app kholo',
      '"Sign Up" pe click karo',
      'Email dalo (wahi jo setup mein hai)',
      'Password dalo (accounts wala)',
      'Username → shop ka naam use karo',
      'Business account select karo → Shop category',
      'Bio add karo',
      'Profile photo upload karo',
      'Contact info mein phone + address dalo',
      'Username note karo'
    ]
  },
  facebook: {
    label: 'Facebook',
    color: '#1877f2',
    bg: 'rgba(24,119,242,0.1)',
    border: 'rgba(24,119,242,0.2)',
    steps: [
      'Facebook.com pe jao',
      'Personal account banao (zaruri hai page ke liye)',
      '"Create Page" select karo',
      'Business/Brand choose karo',
      'Page name: shop ka naam',
      'Category select karo (Shopping, Electronics, etc)',
      'Bio add karo',
      'Profile + Cover photo upload karo',
      'Phone aur address add karo',
      'Page username set karo'
    ]
  },
  youtube: {
    label: 'YouTube',
    color: '#ff0000',
    bg: 'rgba(255,0,0,0.1)',
    border: 'rgba(255,0,0,0.2)',
    steps: [
      'youtube.com pe jao',
      'Gmail se sign in karo (wahi email)',
      'Profile pe click karo → "Create a channel"',
      'Channel name: shop ka naam',
      'Channel art upload karo (profile image)',
      'About section mein bio paste karo',
      'Phone aur address add karo',
      'Handle (@username) set karo',
      'Channel URL note karo'
    ]
  }
}

export default function Accounts({ data, updateData, addHistory }) {
  const [selected, setSelected] = useState(null)
  const [editing, setEditing] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [showPass, setShowPass] = useState({})

  const platforms = data.platforms || {}

  const startEdit = (name) => {
    setEditing(name)
    setEditForm({ ...platforms[name] })
    setSelected(name)
  }

  const saveEdit = (name) => {
    const updated = { ...platforms, [name]: { ...editForm } }
    updateData({ platforms: updated })
    addHistory({
      type: 'Account Update',
      description: `${platformMeta[name].label} account info update ki — @${editForm.username || '?'}`
    })
    setEditing(null)
  }

  const markStatus = (name, status) => {
    const updated = {
      ...platforms,
      [name]: {
        ...platforms[name],
        status,
        createdAt: status === 'done' ? new Date().toISOString() : platforms[name].createdAt
      }
    }
    updateData({ platforms: updated })
    addHistory({
      type: 'Account Status',
      description: `${platformMeta[name].label} status: ${status}`
    })
  }

  const inputStyle = {
    width: '100%', padding: '10px 14px', borderRadius: 10,
    background: '#1a1a24', border: '1px solid rgba(255,255,255,0.1)',
    color: '#f0f0f8', fontSize: 13, outline: 'none'
  }

  return (
    <div>
      <div style={{ marginBottom: 36 }}>
        <div style={{ fontFamily: 'Syne', fontSize: 26, fontWeight: 800, color: '#f0f0f8', marginBottom: 6 }}>Social Accounts</div>
        <div style={{ color: '#6868a0', fontSize: 14 }}>Har platform ka account banao aur info save karo</div>
      </div>

      {data.shopName && (
        <div style={{ padding: '16px 20px', background: 'rgba(124,92,252,0.1)', border: '1px solid rgba(124,92,252,0.2)', borderRadius: 14, marginBottom: 28, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          <div><span style={{ color: '#5a5a7a', fontSize: 12 }}>Naam: </span><span style={{ color: '#a78bfa', fontWeight: 500 }}>{data.shopName}</span></div>
          {data.accsPassword && <div><span style={{ color: '#5a5a7a', fontSize: 12 }}>Password: </span><span style={{ color: '#f59e0b', fontWeight: 500, fontFamily: 'monospace' }}>{'•'.repeat(data.accsPassword.length)}</span></div>}
          {data.email && <div><span style={{ color: '#5a5a7a', fontSize: 12 }}>Email: </span><span style={{ color: '#a78bfa', fontWeight: 500 }}>{data.email}</span></div>}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {Object.entries(platformMeta).map(([name, meta]) => {
          const info = platforms[name] || {}
          const isSelected = selected === name
          const isEditing = editing === name

          return (
            <div key={name} style={{
              background: '#111118',
              borderRadius: 20,
              border: `1px solid ${isSelected ? meta.border : 'rgba(255,255,255,0.06)'}`,
              overflow: 'hidden',
              transition: 'border 0.2s'
            }}>
              <div style={{ padding: '20px 22px', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <div style={{ fontFamily: 'Syne', fontSize: 16, fontWeight: 700, color: meta.color }}>{meta.label}</div>
                  <div style={{
                    padding: '4px 12px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                    background: info.status === 'done' ? 'rgba(34,197,94,0.15)' : info.status === 'progress' ? 'rgba(245,158,11,0.15)' : 'rgba(90,90,122,0.15)',
                    color: info.status === 'done' ? '#22c55e' : info.status === 'progress' ? '#f59e0b' : '#5a5a7a'
                  }}>
                    {info.status === 'done' ? '✓ Done' : info.status === 'progress' ? '⟳ Progress' : '○ Pending'}
                  </div>
                </div>

                {info.username && !isEditing && (
                  <div style={{ display: 'flex', gap: 16, marginBottom: 12 }}>
                    <div>
                      <div style={{ fontSize: 10, color: '#5a5a7a', marginBottom: 2 }}>USERNAME</div>
                      <div style={{ fontSize: 13, color: '#f0f0f8', fontFamily: 'monospace' }}>@{info.username}</div>
                    </div>
                    {info.password && (
                      <div>
                        <div style={{ fontSize: 10, color: '#5a5a7a', marginBottom: 2 }}>PASSWORD</div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          <div style={{ fontSize: 13, color: '#f0f0f8', fontFamily: 'monospace' }}>
                            {showPass[name] ? info.password : '••••••••'}
                          </div>
                          <button onClick={() => setShowPass(p => ({ ...p, [name]: !p[name] }))} style={{ background: 'none', border: 'none', color: '#5a5a7a', cursor: 'pointer', fontSize: 11 }}>
                            {showPass[name] ? 'Hide' : 'Show'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {isEditing && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 14 }}>
                    <input style={inputStyle} placeholder="Username (@ ke baghair)" value={editForm.username || ''} onChange={e => setEditForm(f => ({ ...f, username: e.target.value }))} />
                    <input style={inputStyle} type="password" placeholder="Password" value={editForm.password || ''} onChange={e => setEditForm(f => ({ ...f, password: e.target.value }))} />
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button onClick={() => saveEdit(name)} style={{ flex: 1, padding: '9px', background: meta.bg, border: `1px solid ${meta.border}`, borderRadius: 10, color: meta.color, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Save</button>
                      <button onClick={() => setEditing(null)} style={{ padding: '9px 14px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: '#6868a0', fontSize: 13, cursor: 'pointer' }}>Cancel</button>
                    </div>
                  </div>
                )}

                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => setSelected(isSelected ? null : name)} style={{
                    flex: 1, padding: '9px', background: isSelected ? meta.bg : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${isSelected ? meta.border : 'rgba(255,255,255,0.08)'}`,
                    borderRadius: 10, color: isSelected ? meta.color : '#6868a0', fontSize: 12, fontWeight: 500, cursor: 'pointer'
                  }}>
                    {isSelected ? 'Steps Chupao' : 'Steps Dekho'}
                  </button>
                  <button onClick={() => startEdit(name)} style={{ padding: '9px 14px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, color: '#9898b8', fontSize: 12, cursor: 'pointer' }}>Edit</button>
                </div>
              </div>

              <div style={{ padding: '14px 22px', display: 'flex', gap: 8 }}>
                {['pending', 'progress', 'done'].map(s => (
                  <button key={s} onClick={() => markStatus(name, s)} style={{
                    flex: 1, padding: '7px', borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: 'pointer',
                    background: info.status === s ? (s === 'done' ? 'rgba(34,197,94,0.2)' : s === 'progress' ? 'rgba(245,158,11,0.2)' : 'rgba(90,90,122,0.2)') : 'transparent',
                    border: `1px solid ${info.status === s ? (s === 'done' ? 'rgba(34,197,94,0.4)' : s === 'progress' ? 'rgba(245,158,11,0.4)' : 'rgba(90,90,122,0.3)') : 'rgba(255,255,255,0.06)'}`,
                    color: info.status === s ? (s === 'done' ? '#22c55e' : s === 'progress' ? '#f59e0b' : '#9898b8') : '#5a5a7a'
                  }}>{s === 'pending' ? 'Pending' : s === 'progress' ? 'Progress' : 'Done ✓'}</button>
                ))}
              </div>

              {isSelected && (
                <div style={{ padding: '0 22px 22px', borderTop: '1px solid rgba(255,255,255,0.04)' }}>
                  <div style={{ fontSize: 11, color: '#5a5a7a', textTransform: 'uppercase', letterSpacing: '0.08em', marginTop: 16, marginBottom: 12 }}>Step-by-Step Guide</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    {meta.steps.map((step, i) => (
                      <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                        <div style={{
                          width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                          background: meta.bg, border: `1px solid ${meta.border}`,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: 10, fontWeight: 700, color: meta.color
                        }}>{i + 1}</div>
                        <div style={{ fontSize: 13, color: '#9898b8', paddingTop: 2, lineHeight: 1.5 }}>
                          {step.replace('(Setup mein di hui email use karo)', `(${data.email || 'email setup se'})`)}
                        </div>
                      </div>
                    ))}
                  </div>
                  {data.shopName && (
                    <div style={{ marginTop: 16, padding: '12px 14px', background: 'rgba(124,92,252,0.08)', border: '1px solid rgba(124,92,252,0.15)', borderRadius: 10 }}>
                      <div style={{ fontSize: 11, color: '#a78bfa', fontWeight: 600, marginBottom: 6 }}>Tumhari Info:</div>
                      <div style={{ fontSize: 12, color: '#9898b8', display: 'flex', flexDirection: 'column', gap: 3 }}>
                        <span>Naam: <span style={{ color: '#f0f0f8' }}>{data.shopName}</span></span>
                        {data.bio && <span>Bio: <span style={{ color: '#f0f0f8' }}>{data.bio.slice(0, 60)}{data.bio.length > 60 ? '...' : ''}</span></span>}
                        {data.phone && <span>Phone: <span style={{ color: '#f0f0f8' }}>{data.phone}</span></span>}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
