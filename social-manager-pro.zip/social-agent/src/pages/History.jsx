const typeColors = {
  'Setup': '#a78bfa',
  'Account Update': '#e1306c',
  'Account Status': '#1877f2',
  'Post Added': '#22c55e',
  'Post Status': '#f59e0b',
}

export default function History({ data, updateData }) {
  const history = data.history || []

  const clearHistory = () => {
    if (window.confirm('Puri history delete karni hai?')) {
      updateData({ history: [] })
    }
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 36 }}>
        <div>
          <div style={{ fontFamily: 'Syne', fontSize: 26, fontWeight: 800, color: '#f0f0f8', marginBottom: 6 }}>Activity History</div>
          <div style={{ color: '#6868a0', fontSize: 14 }}>Sab kuch yahan record hota hai — kab kya kiya</div>
        </div>
        {history.length > 0 && (
          <button onClick={clearHistory} style={{ padding: '10px 18px', background: 'rgba(255,45,85,0.1)', border: '1px solid rgba(255,45,85,0.2)', borderRadius: 10, color: '#ff2d55', fontSize: 13, cursor: 'pointer' }}>
            Clear All
          </button>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 32 }}>
        {Object.entries(typeColors).map(([type, color]) => {
          const count = history.filter(h => h.type === type).length
          return (
            <div key={type} style={{ padding: '16px 18px', background: '#111118', borderRadius: 14, border: '1px solid rgba(255,255,255,0.06)' }}>
              <div style={{ fontSize: 22, fontFamily: 'Syne', fontWeight: 800, color, marginBottom: 4 }}>{count}</div>
              <div style={{ fontSize: 11, color: '#5a5a7a' }}>{type}</div>
            </div>
          )
        })}
      </div>

      {history.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#5a5a7a' }}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>📋</div>
          <div style={{ fontFamily: 'Syne', fontSize: 16 }}>Abhi koi history nahi</div>
          <div style={{ fontSize: 13, marginTop: 6 }}>Jab bhi koi kaam karoge, yahan nazar aaega</div>
        </div>
      ) : (
        <div style={{ position: 'relative' }}>
          <div style={{ position: 'absolute', left: 18, top: 0, bottom: 0, width: 1, background: 'rgba(255,255,255,0.06)' }} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {history.map((entry, i) => {
              const color = typeColors[entry.type] || '#5a5a7a'
              return (
                <div key={entry.id || i} style={{ display: 'flex', gap: 20, paddingLeft: 0 }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: '50%', flexShrink: 0,
                    background: `${color}15`, border: `1px solid ${color}33`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    marginLeft: 0, position: 'relative', zIndex: 1
                  }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />
                  </div>
                  <div style={{
                    flex: 1, background: '#111118', borderRadius: 14,
                    border: '1px solid rgba(255,255,255,0.06)',
                    padding: '14px 18px', marginBottom: 4
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                        <span style={{
                          padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                          background: `${color}15`, color, border: `1px solid ${color}33`
                        }}>{entry.type}</span>
                      </div>
                      <div style={{ fontSize: 11, color: '#3a3a5a' }}>
                        {new Date(entry.timestamp).toLocaleString('en-PK', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    <div style={{ fontSize: 13, color: '#9898b8', lineHeight: 1.5 }}>{entry.description}</div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
