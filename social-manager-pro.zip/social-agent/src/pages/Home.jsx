const platformInfo = {
  tiktok: { color: '#ff2d55', bg: 'rgba(255,45,85,0.12)', label: 'TikTok' },
  instagram: { color: '#e1306c', bg: 'rgba(225,48,108,0.12)', label: 'Instagram' },
  facebook: { color: '#1877f2', bg: 'rgba(24,119,242,0.12)', label: 'Facebook' },
  youtube: { color: '#ff0000', bg: 'rgba(255,0,0,0.12)', label: 'YouTube' },
}

const TikTokIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.18 8.18 0 0 0 4.78 1.52V6.75a4.85 4.85 0 0 1-1.01-.06z"/>
  </svg>
)

const IGIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
  </svg>
)

const FBIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
  </svg>
)

const YTIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/>
  </svg>
)

const platformIcons = { tiktok: TikTokIcon, instagram: IGIcon, facebook: FBIcon, youtube: YTIcon }

export default function Home({ data, setPage }) {
  const platforms = data.platforms || {}
  const totalPosts = data.posts?.length || 0
  const activePlatforms = Object.values(platforms).filter(p => p.status === 'done').length
  const historyCount = data.history?.length || 0
  const isSetup = !!data.shopName

  const recentHistory = (data.history || []).slice(0, 3)

  return (
    <div>
      <div style={{ marginBottom: 40 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 8 }}>
          <div style={{ fontFamily: 'Syne', fontSize: 28, fontWeight: 800, color: '#f0f0f8' }}>
            {isSetup ? `Welcome, ${data.shopName}` : 'Social Manager Pro'}
          </div>
          {isSetup && (
            <div style={{
              padding: '4px 12px', borderRadius: 20,
              background: 'rgba(34,197,94,0.12)',
              border: '1px solid rgba(34,197,94,0.2)',
              color: '#22c55e', fontSize: 12, fontWeight: 500
            }}>Active</div>
          )}
        </div>
        <div style={{ color: '#6868a0', fontSize: 15 }}>
          {isSetup ? 'Apne social media accounts manage karo yahan se' : 'Shuru karne ke liye shop setup karo'}
        </div>
      </div>

      {!isSetup && (
        <div style={{
          padding: '28px 32px',
          background: 'linear-gradient(135deg, rgba(124,92,252,0.15), rgba(168,85,247,0.08))',
          border: '1px solid rgba(124,92,252,0.3)',
          borderRadius: 20,
          marginBottom: 32,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <div style={{ fontFamily: 'Syne', fontSize: 20, fontWeight: 700, color: '#f0f0f8', marginBottom: 6 }}>
              Pehle Shop Setup Karo
            </div>
            <div style={{ color: '#9898b8', fontSize: 14 }}>
              Apni shop ki info, email, aur profile image dalo
            </div>
          </div>
          <button onClick={() => setPage('setup')} style={{
            padding: '12px 24px',
            background: 'linear-gradient(135deg, #7c5cfc, #a855f7)',
            border: 'none',
            borderRadius: 12,
            color: 'white',
            fontWeight: 600,
            fontSize: 14,
            cursor: 'pointer'
          }}>Setup Shuru Karo →</button>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
        {[
          { label: 'Active Platforms', value: activePlatforms, total: '/4', color: '#a78bfa' },
          { label: 'Total Posts', value: totalPosts, color: '#22c55e' },
          { label: 'History Entries', value: historyCount, color: '#f59e0b' },
          { label: 'Setup Status', value: isSetup ? '✓' : '—', color: isSetup ? '#22c55e' : '#5a5a7a' },
        ].map((stat, i) => (
          <div key={i} style={{
            padding: '20px 22px',
            background: '#111118',
            borderRadius: 16,
            border: '1px solid rgba(255,255,255,0.06)'
          }}>
            <div style={{ fontSize: 12, color: '#5a5a7a', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{stat.label}</div>
            <div style={{ fontSize: 32, fontFamily: 'Syne', fontWeight: 800, color: stat.color }}>
              {stat.value}{stat.total || ''}
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 32 }}>
        <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(255,255,255,0.06)', padding: '24px' }}>
          <div style={{ fontFamily: 'Syne', fontSize: 16, fontWeight: 700, color: '#f0f0f8', marginBottom: 20 }}>Platform Status</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {Object.entries(platforms).map(([name, info]) => {
              const meta = platformInfo[name]
              const Icon = platformIcons[name]
              return (
                <div key={name} style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 14,
                  padding: '12px 16px',
                  background: meta.bg,
                  borderRadius: 12,
                  border: `1px solid ${meta.color}22`
                }}>
                  <span style={{ color: meta.color }}><Icon /></span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 500, color: '#f0f0f8' }}>{meta.label}</div>
                    {info.username && <div style={{ fontSize: 12, color: '#6868a0' }}>@{info.username}</div>}
                  </div>
                  <div style={{
                    padding: '4px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                    background: info.status === 'done' ? 'rgba(34,197,94,0.15)' : info.status === 'progress' ? 'rgba(245,158,11,0.15)' : 'rgba(90,90,122,0.2)',
                    color: info.status === 'done' ? '#22c55e' : info.status === 'progress' ? '#f59e0b' : '#5a5a7a'
                  }}>
                    {info.status === 'done' ? 'Done' : info.status === 'progress' ? 'Progress' : 'Pending'}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(255,255,255,0.06)', padding: '24px', flex: 1 }}>
            <div style={{ fontFamily: 'Syne', fontSize: 16, fontWeight: 700, color: '#f0f0f8', marginBottom: 16 }}>Quick Actions</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { label: 'Shop Setup Update Karo', page: 'setup', color: '#7c5cfc' },
                { label: 'Account Banao / Dekho', page: 'accounts', color: '#e1306c' },
                { label: 'Post Add Karo', page: 'posts', color: '#22c55e' },
                { label: 'History Dekho', page: 'history', color: '#f59e0b' },
              ].map(item => (
                <button key={item.page} onClick={() => setPage(item.page)} style={{
                  padding: '11px 16px',
                  background: `${item.color}11`,
                  border: `1px solid ${item.color}33`,
                  borderRadius: 10,
                  color: item.color,
                  fontSize: 13,
                  fontWeight: 500,
                  textAlign: 'left',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8
                }}>
                  <span>→</span> {item.label}
                </button>
              ))}
            </div>
          </div>

          {recentHistory.length > 0 && (
            <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(255,255,255,0.06)', padding: '20px' }}>
              <div style={{ fontFamily: 'Syne', fontSize: 14, fontWeight: 700, color: '#f0f0f8', marginBottom: 12 }}>Recent Activity</div>
              {recentHistory.map(h => (
                <div key={h.id} style={{ padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.04)', fontSize: 12, color: '#6868a0' }}>
                  <span style={{ color: '#a78bfa' }}>{h.type}</span> — {h.description?.slice(0, 40)}
                  <div style={{ fontSize: 10, marginTop: 2 }}>{new Date(h.timestamp).toLocaleDateString('ur-PK')}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {isSetup && (
        <div style={{
          padding: '20px 24px',
          background: '#111118',
          borderRadius: 16,
          border: '1px solid rgba(255,255,255,0.06)',
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: 20
        }}>
          {data.email && <div><div style={{ fontSize: 11, color: '#5a5a7a', marginBottom: 4 }}>EMAIL</div><div style={{ fontSize: 13, color: '#9898b8' }}>{data.email}</div></div>}
          {data.phone && <div><div style={{ fontSize: 11, color: '#5a5a7a', marginBottom: 4 }}>PHONE</div><div style={{ fontSize: 13, color: '#9898b8' }}>{data.phone}</div></div>}
          {data.address && <div><div style={{ fontSize: 11, color: '#5a5a7a', marginBottom: 4 }}>ADDRESS</div><div style={{ fontSize: 13, color: '#9898b8' }}>{data.address.slice(0, 40)}...</div></div>}
        </div>
      )}
    </div>
  )
}
