import { useState } from 'react'

const platformColors = {
  tiktok: '#ff2d55', instagram: '#e1306c', facebook: '#1877f2', youtube: '#ff0000', all: '#a78bfa'
}

export default function Posts({ data, updateData, addHistory }) {
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ caption: '', platforms: [], image: null, scheduledDate: '', status: 'pending' })
  const [filter, setFilter] = useState('all')

  const posts = data.posts || []

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onloadend = () => setForm(f => ({ ...f, image: reader.result }))
    reader.readAsDataURL(file)
  }

  const togglePlatform = (p) => {
    setForm(f => ({
      ...f,
      platforms: f.platforms.includes(p)
        ? f.platforms.filter(x => x !== p)
        : [...f.platforms, p]
    }))
  }

  const selectAllPlatforms = () => {
    setForm(f => ({
      ...f,
      platforms: f.platforms.length === 4 ? [] : ['tiktok', 'instagram', 'facebook', 'youtube']
    }))
  }

  const addPost = () => {
    if (!form.caption && !form.image) return
    const newPost = { ...form, id: Date.now(), createdAt: new Date().toISOString() }
    updateData({ posts: [...posts, newPost] })
    addHistory({ type: 'Post Added', description: `Post add ki: "${form.caption?.slice(0, 40) || 'Image post'}"` })
    setForm({ caption: '', platforms: [], image: null, scheduledDate: '', status: 'pending' })
    setShowForm(false)
  }

  const updatePostStatus = (id, status) => {
    updateData({ posts: posts.map(p => p.id === id ? { ...p, status } : p) })
    addHistory({ type: 'Post Status', description: `Post status update: ${status}` })
  }

  const deletePost = (id) => {
    updateData({ posts: posts.filter(p => p.id !== id) })
  }

  const filteredPosts = filter === 'all' ? posts : posts.filter(p => p.platforms?.includes(filter))

  const inputStyle = { width: '100%', padding: '11px 14px', borderRadius: 10, background: '#1a1a24', border: '1px solid rgba(255,255,255,0.1)', color: '#f0f0f8', fontSize: 14, outline: 'none' }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 36 }}>
        <div>
          <div style={{ fontFamily: 'Syne', fontSize: 26, fontWeight: 800, color: '#f0f0f8', marginBottom: 6 }}>Posts Manager</div>
          <div style={{ color: '#6868a0', fontSize: 14 }}>Posts add karo aur sabhi platforms pe track karo</div>
        </div>
        <button onClick={() => setShowForm(!showForm)} style={{
          padding: '12px 22px',
          background: showForm ? 'rgba(255,255,255,0.05)' : 'linear-gradient(135deg, #7c5cfc, #a855f7)',
          border: showForm ? '1px solid rgba(255,255,255,0.1)' : 'none',
          borderRadius: 12, color: showForm ? '#6868a0' : 'white',
          fontWeight: 600, fontSize: 14, cursor: 'pointer'
        }}>
          {showForm ? '× Cancel' : '+ New Post'}
        </button>
      </div>

      {showForm && (
        <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(124,92,252,0.2)', padding: 28, marginBottom: 28 }}>
          <div style={{ fontFamily: 'Syne', fontSize: 16, fontWeight: 700, color: '#a78bfa', marginBottom: 22 }}>Nai Post</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <div style={{ fontSize: 11, color: '#5a5a7a', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Caption / Text</div>
              <textarea style={{ ...inputStyle, minHeight: 100, resize: 'vertical' }} value={form.caption} onChange={e => setForm(f => ({ ...f, caption: e.target.value }))} placeholder="Post ka content likho..." />
            </div>

            <div>
              <div style={{ fontSize: 11, color: '#5a5a7a', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Post Image (Optional)</div>
              {form.image ? (
                <div style={{ position: 'relative', display: 'inline-block' }}>
                  <img src={form.image} alt="" style={{ height: 120, width: 'auto', borderRadius: 10, objectFit: 'cover' }} />
                  <button onClick={() => setForm(f => ({ ...f, image: null }))} style={{ position: 'absolute', top: 6, right: 6, background: 'rgba(0,0,0,0.7)', border: 'none', color: 'white', borderRadius: '50%', width: 22, height: 22, fontSize: 12, cursor: 'pointer' }}>×</button>
                </div>
              ) : (
                <>
                  <input type="file" accept="image/*" onChange={handleImageUpload} id="postImg" style={{ display: 'none' }} />
                  <label htmlFor="postImg" style={{ display: 'inline-block', padding: '10px 18px', background: 'rgba(255,255,255,0.04)', border: '1px dashed rgba(255,255,255,0.15)', borderRadius: 10, color: '#6868a0', fontSize: 13, cursor: 'pointer' }}>+ Image Upload</label>
                </>
              )}
            </div>

            <div>
              <div style={{ fontSize: 11, color: '#5a5a7a', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>Platforms (Kahan Post Hogi)</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button onClick={selectAllPlatforms} style={{
                  padding: '8px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer',
                  background: form.platforms.length === 4 ? 'rgba(167,139,250,0.2)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${form.platforms.length === 4 ? 'rgba(167,139,250,0.4)' : 'rgba(255,255,255,0.1)'}`,
                  color: form.platforms.length === 4 ? '#a78bfa' : '#6868a0'
                }}>All Platforms</button>
                {['tiktok', 'instagram', 'facebook', 'youtube'].map(p => (
                  <button key={p} onClick={() => togglePlatform(p)} style={{
                    padding: '8px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', textTransform: 'capitalize',
                    background: form.platforms.includes(p) ? `rgba(${p === 'tiktok' ? '255,45,85' : p === 'instagram' ? '225,48,108' : p === 'facebook' ? '24,119,242' : '255,0,0'},0.15)` : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${form.platforms.includes(p) ? platformColors[p] + '44' : 'rgba(255,255,255,0.1)'}`,
                    color: form.platforms.includes(p) ? platformColors[p] : '#6868a0'
                  }}>{p}</button>
                ))}
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div>
                <div style={{ fontSize: 11, color: '#5a5a7a', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Schedule Date (Optional)</div>
                <input type="date" style={inputStyle} value={form.scheduledDate} onChange={e => setForm(f => ({ ...f, scheduledDate: e.target.value }))} />
              </div>
              <div>
                <div style={{ fontSize: 11, color: '#5a5a7a', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Status</div>
                <select style={inputStyle} value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
                  <option value="pending">Pending</option>
                  <option value="posted">Posted</option>
                  <option value="scheduled">Scheduled</option>
                </select>
              </div>
            </div>

            <button onClick={addPost} disabled={!form.caption && !form.image} style={{
              padding: '14px', background: 'linear-gradient(135deg, #7c5cfc, #a855f7)',
              border: 'none', borderRadius: 12, color: 'white', fontWeight: 700,
              fontSize: 14, cursor: 'pointer', fontFamily: 'Syne',
              opacity: !form.caption && !form.image ? 0.4 : 1
            }}>Post Save Karo</button>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
        {['all', 'tiktok', 'instagram', 'facebook', 'youtube'].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            padding: '7px 16px', borderRadius: 20, fontSize: 12, fontWeight: 500, cursor: 'pointer', textTransform: 'capitalize',
            background: filter === f ? `${platformColors[f]}20` : 'rgba(255,255,255,0.04)',
            border: `1px solid ${filter === f ? platformColors[f] + '44' : 'rgba(255,255,255,0.08)'}`,
            color: filter === f ? platformColors[f] : '#6868a0'
          }}>{f === 'all' ? `Sab (${posts.length})` : f}</button>
        ))}
      </div>

      {filteredPosts.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#5a5a7a' }}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>📝</div>
          <div style={{ fontFamily: 'Syne', fontSize: 16, marginBottom: 6 }}>Koi post nahi</div>
          <div style={{ fontSize: 13 }}>Upar "+ New Post" se post add karo</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {filteredPosts.slice().reverse().map(post => (
            <div key={post.id} style={{ background: '#111118', borderRadius: 16, border: '1px solid rgba(255,255,255,0.06)', overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                {post.image && <img src={post.image} alt="" style={{ width: 72, height: 72, borderRadius: 10, objectFit: 'cover', flexShrink: 0 }} />}
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, color: '#f0f0f8', lineHeight: 1.5, marginBottom: 10 }}>
                    {post.caption || <span style={{ color: '#5a5a7a' }}>Image only post</span>}
                  </div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
                    {(post.platforms || []).map(p => (
                      <span key={p} style={{
                        padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600, textTransform: 'capitalize',
                        background: `${platformColors[p]}20`, color: platformColors[p],
                        border: `1px solid ${platformColors[p]}33`
                      }}>{p}</span>
                    ))}
                  </div>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                    <div style={{ fontSize: 11, color: '#3a3a5a' }}>
                      {new Date(post.createdAt).toLocaleDateString('ur-PK')}
                      {post.scheduledDate && <span style={{ marginLeft: 8, color: '#f59e0b' }}>📅 {post.scheduledDate}</span>}
                    </div>
                    <div style={{ display: 'flex', gap: 6 }}>
                      {['pending', 'posted', 'scheduled'].map(s => (
                        <button key={s} onClick={() => updatePostStatus(post.id, s)} style={{
                          padding: '4px 10px', borderRadius: 20, fontSize: 11, fontWeight: 500, cursor: 'pointer', textTransform: 'capitalize',
                          background: post.status === s ? (s === 'posted' ? 'rgba(34,197,94,0.2)' : s === 'scheduled' ? 'rgba(245,158,11,0.2)' : 'rgba(90,90,122,0.2)') : 'transparent',
                          border: `1px solid ${post.status === s ? (s === 'posted' ? 'rgba(34,197,94,0.4)' : s === 'scheduled' ? 'rgba(245,158,11,0.4)' : 'rgba(90,90,122,0.3)') : 'rgba(255,255,255,0.06)'}`,
                          color: post.status === s ? (s === 'posted' ? '#22c55e' : s === 'scheduled' ? '#f59e0b' : '#9898b8') : '#5a5a7a'
                        }}>{s}</button>
                      ))}
                    </div>
                  </div>
                </div>
                <button onClick={() => deletePost(post.id)} style={{ background: 'none', border: 'none', color: '#3a3a5a', cursor: 'pointer', fontSize: 16, padding: '4px 8px' }}>×</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
