import { useState } from 'react'

export default function Setup({ data, updateData, addHistory }) {
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({
    shopName: data.shopName || '',
    bio: data.bio || '',
    address: data.address || '',
    phone: data.phone || '',
    email: data.email || '',
    emailPassword: data.emailPassword || '',
    accsPassword: data.accsPassword || '',
    profileImage: data.profileImage || null,
  })

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onloadend = () => {
      setForm(f => ({ ...f, profileImage: reader.result }))
    }
    reader.readAsDataURL(file)
  }

  const handleSave = () => {
    updateData(form)
    addHistory({ type: 'Setup', description: `Shop setup update: ${form.shopName}` })
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const inputStyle = { width: '100%', padding: '12px 16px', borderRadius: 12, background: '#1a1a24', border: '1px solid rgba(255,255,255,0.1)', color: '#f0f0f8', fontSize: 14, outline: 'none' }
  const labelStyle = { fontSize: 12, color: '#6868a0', marginBottom: 6, display: 'block', textTransform: 'uppercase', letterSpacing: '0.08em' }

  return (
    <div style={{ maxWidth: 700 }}>
      <div style={{ marginBottom: 36 }}>
        <div style={{ fontFamily: 'Syne', fontSize: 26, fontWeight: 800, color: '#f0f0f8', marginBottom: 6 }}>Shop Setup</div>
        <div style={{ color: '#6868a0', fontSize: 14 }}>Apni shop ki tamam info yahan save karo</div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(255,255,255,0.06)', padding: 28 }}>
          <div style={{ fontFamily: 'Syne', fontSize: 15, fontWeight: 700, color: '#a78bfa', marginBottom: 20 }}>Profile Image</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <div style={{
              width: 80, height: 80, borderRadius: '50%',
              background: form.profileImage ? 'transparent' : 'rgba(124,92,252,0.15)',
              border: '2px dashed rgba(124,92,252,0.4)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              overflow: 'hidden', cursor: 'pointer', flexShrink: 0
            }}>
              {form.profileImage
                ? <img src={form.profileImage} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <span style={{ fontSize: 28, color: '#a78bfa' }}>+</span>
              }
            </div>
            <div>
              <input type="file" accept="image/*" onChange={handleImageUpload} id="imgUpload" style={{ display: 'none' }} />
              <label htmlFor="imgUpload" style={{
                padding: '10px 20px',
                background: 'rgba(124,92,252,0.15)',
                border: '1px solid rgba(124,92,252,0.3)',
                borderRadius: 10, color: '#a78bfa', fontSize: 13, fontWeight: 500, cursor: 'pointer'
              }}>Image Upload Karo</label>
              <div style={{ fontSize: 11, color: '#5a5a7a', marginTop: 8 }}>PNG, JPG — Max 5MB</div>
              {form.profileImage && (
                <button onClick={() => setForm(f => ({ ...f, profileImage: null }))} style={{ marginTop: 8, background: 'none', border: 'none', color: '#ff2d55', fontSize: 12, cursor: 'pointer' }}>Remove</button>
              )}
            </div>
          </div>
        </div>

        <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(255,255,255,0.06)', padding: 28 }}>
          <div style={{ fontFamily: 'Syne', fontSize: 15, fontWeight: 700, color: '#a78bfa', marginBottom: 20 }}>Shop Info</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={labelStyle}>Shop Ka Naam *</label>
              <input style={inputStyle} value={form.shopName} onChange={e => setForm(f => ({ ...f, shopName: e.target.value }))} placeholder="Jaise: Ali Electronics" />
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={labelStyle}>Bio (Tamam Platforms Pe Jaega)</label>
              <textarea style={{ ...inputStyle, minHeight: 90, resize: 'vertical' }} value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} placeholder="Apni shop ki chhoti si pehchaan..." />
            </div>
            <div>
              <label style={labelStyle}>Phone Number</label>
              <input style={inputStyle} value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+92 300 1234567" />
            </div>
            <div>
              <label style={labelStyle}>Address</label>
              <input style={inputStyle} value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="Gali 5, Lahore" />
            </div>
          </div>
        </div>

        <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(255,255,255,0.06)', padding: 28 }}>
          <div style={{ fontFamily: 'Syne', fontSize: 15, fontWeight: 700, color: '#22c55e', marginBottom: 8 }}>Login Email</div>
          <div style={{ fontSize: 12, color: '#5a5a7a', marginBottom: 20 }}>Yeh email sabse pehle accounts banane ke liye use hogi</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div>
              <label style={labelStyle}>Email Address</label>
              <input style={inputStyle} type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="shop@gmail.com" />
            </div>
            <div>
              <label style={labelStyle}>Email Password</label>
              <input style={inputStyle} type="password" value={form.emailPassword} onChange={e => setForm(f => ({ ...f, emailPassword: e.target.value }))} placeholder="Email ka password" />
            </div>
          </div>
        </div>

        <div style={{ background: '#111118', borderRadius: 20, border: '1px solid rgba(245,158,11,0.15)', padding: 28, borderColor: 'rgba(245,158,11,0.2)' }}>
          <div style={{ fontFamily: 'Syne', fontSize: 15, fontWeight: 700, color: '#f59e0b', marginBottom: 8 }}>Accounts Password</div>
          <div style={{ fontSize: 12, color: '#5a5a7a', marginBottom: 20 }}>Yeh password sabhi social media accounts pe lagega</div>
          <div>
            <label style={labelStyle}>Accounts Ka Password</label>
            <input style={{ ...inputStyle, borderColor: 'rgba(245,158,11,0.3)' }} type="password" value={form.accsPassword} onChange={e => setForm(f => ({ ...f, accsPassword: e.target.value }))} placeholder="Strong password dalo" />
          </div>
          <div style={{ marginTop: 12, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {['8+ characters', 'Number shamil ho', 'Special char !@#'].map(tip => (
              <div key={tip} style={{ padding: '4px 10px', background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 20, fontSize: 11, color: '#f59e0b' }}>{tip}</div>
            ))}
          </div>
        </div>

        <button onClick={handleSave} style={{
          padding: '16px',
          background: saved ? 'rgba(34,197,94,0.2)' : 'linear-gradient(135deg, #7c5cfc, #a855f7)',
          border: saved ? '1px solid rgba(34,197,94,0.4)' : 'none',
          borderRadius: 14,
          color: saved ? '#22c55e' : 'white',
          fontSize: 15,
          fontWeight: 700,
          fontFamily: 'Syne',
          cursor: 'pointer',
          transition: 'all 0.3s'
        }}>
          {saved ? '✓ Save Ho Gaya!' : 'Save Karo'}
        </button>
      </div>
    </div>
  )
}
